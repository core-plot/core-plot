#import <Foundation/Foundation.h>

@interface NSNumber(CPExtensions)

-(NSDecimalNumber *)decimalNumber;

@end

