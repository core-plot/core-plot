
#import <Foundation/Foundation.h>
#import "CPXYTheme.h"

@interface CPStocksTheme : CPXYTheme {

}

@end
